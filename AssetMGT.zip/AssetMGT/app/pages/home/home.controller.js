'use strict';

angular.module('myApp')

    .controller('homeCtrl', function ($scope, appSettings, MqttClient, MessageService) {

        console.log('home contoller..');


        var ip = appSettings.serverPath;
        var port = appSettings.websocketsPort;
        var id = "";

        MqttClient.init(ip, port, id);

        $scope.connect = function connect() {
            console.log('connecting...');
            MqttClient.connect({onSuccess: successCallback});
        }

        $scope.subscribe = function subscribe()  {
            MqttClient.subscribe('#');
        }

        $scope.unSubscribe = function unSubscribe() {
            MqttClient.unsubscribe();
        }

        $scope.disConnect = function disConnect() {
            MqttClient.disconnect();
        }

        function successCallback() {

            console.log('connected..');

        }

    });