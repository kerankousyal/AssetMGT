(function(){
    'use strict';

    angular.module('myApp').

    component('tileList', {
        // isolated scope binding
        bindings: {
            mgs:'<'
        },

        // Inline template which is binded to message variable
        // in the component controller
        templateUrl : 'pages/home/components/tile/tile.html',

        transclude: true,

        // The controller that handles our component logic
        controller: function ($scope, $element, $attrs ) {

            $scope.mgs = '';

            $scope.$on('messages:updated', function(event,data) {
                //console.log('broadcast:'+data);
                $scope.mgs =data;
            });
        }
    });

})();