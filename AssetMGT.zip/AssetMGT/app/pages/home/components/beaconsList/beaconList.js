(function(){
    'use strict';

    angular.module('myApp').

    component('beaconList', {
        // isolated scope binding
        bindings: {
            messages:'<'
        },

        // Inline template which is binded to message variable
        // in the component controller
        templateUrl : 'pages/home/components/beaconsList/beaconList.html',

        // The controller that handles our component logic
        controller: function ($scope) {

            $scope.messages = '';

            $scope.$on('messages:updated', function(event,data) {
                 //console.log('broadcast:'+data);
                $scope.messages =data;
            });

        }
    });

})();