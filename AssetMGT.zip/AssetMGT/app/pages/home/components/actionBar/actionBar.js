(function () {
    'use strict';

    angular.module('myApp')

        .component('actionBar', {

            bindings: {

                onButtonAction: '&'
            },
            templateUrl: 'pages/home/components/actionBar/actionBar.view.html',

            controller: function () {

                this.setAction = function (requestedAction) {

                    console.log(requestedAction);

                    this.onButtonAction({$event: {buttonAction: requestedAction}});
                }

            }



        });
})();