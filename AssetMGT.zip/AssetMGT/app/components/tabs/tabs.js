(function(){
    'use strict';

    angular.module('myApp').

    component('tabs', {
        // isolated scope binding


        // Inline template which is binded to message variable
        // in the component controller
        templateUrl : 'components/tabs/tabs.html',

        transclude: true,

        // The controller that handles our component logic
        controller: function ($scope, $element, $attrs ) {

            var vm = this;

            vm.panes = [];
            vm.select = select;
            vm.addPane = addPane;

            function select( pane ) {
                angular.forEach( vm.panes, function( pane ) {
                    pane.selected = '';
                });
                pane.selected = 'active';
            }

            function addPane( pane ) {
                vm.panes.push( pane );
                if ( vm.panes.length === 1 ) {
                    select( pane );
                }
            }

        }
    }).
    component( 'tabPane', {

            transclude: true,
            require: {
                tabs: '^tabs'
            },
            bindings: {
                title: '@',
                icon:  '@'
            },
            template: '<div class="tab-pane {{$ctrl.selected}}"><ng-transclude></ng-transclude></div>',

            controller : function () {

                var vm = this;

                init();

                function init() {
                    vm.$onInit = function() {
                        vm.tabs.addPane( this );
                    }
                }
            }
        });

})();