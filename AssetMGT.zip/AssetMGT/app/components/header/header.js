(function(){
    'use strict';

    angular.module('myApp').

    component('header', {
    // isolated scope binding
        bindings: {
            brand:'<'
        },

    // Inline template which is binded to message variable
    // in the component controller
        templateUrl : 'components/header/header.html',

    // The controller that handles our component logic
    controller: function () {

        this.brand= 'Logo';

        function preventClick($event) {
            $event.preventDefault();
        }

        // A list of menus
        this.menu = [{
            name: "Asset Management",
            component: "Asset Management"
        }, {
            name: "Time & Attendence",
            component: "Time & Attendence"
        }, {
            name: "Configure",
            component: "Configure"
        }, {
            name: "Help",
            component: "Help"
            }];

    }
});

})();