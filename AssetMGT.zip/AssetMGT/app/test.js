let name = 'World';
let greeting = `Hello ${name}!`