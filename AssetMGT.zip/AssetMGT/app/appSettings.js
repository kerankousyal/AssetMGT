(function () {
    "use strict";
    angular
        .module("myApp")
        .constant("appSettings", {
            serverPath: "ec2-54-210-16-12.compute-1.amazonaws.com",
            mqttPort : 1883,
            websocketsPort : 9001,
            topic : '#',
            gateways : {'D706EFC57465': 'Tor1', 'CF8A249B1770' : 'Tor2', 'C0AB9994EEB9' : 'Ahmd1', 'F999DF8C574B' : 'Ahmd2'}
        });
}());

