(function () {

    angular.module('myApp').
    config(['$routeProvider','$locationProvider', '$compileProvider', function($routeProvider, $locationProvider,  $compileProvider) {

        $routeProvider.when('/home', {
            templateUrl: 'pages/home/home.view.html',
            controller: 'homeCtrl'
        }).

        otherwise({redirectTo: '/home'});

        $compileProvider.debugInfoEnabled(false);

    }]);

})();



