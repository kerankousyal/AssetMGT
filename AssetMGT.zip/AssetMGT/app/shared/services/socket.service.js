
angular
    .module('myApp').factory('MqttClient', function ($rootScope, appSettings, MessageService) {

    // so we can use the member attributes inside our functions
    var client = {};

    // initialize attributes
    client._location = "";
    client._port = "";
    client._id = "";
    client._client = null;
    client._isConnected = false;

    // member functions
    client.init = init;
    client.connect = connect;
    client.disconnect = disconnect;
    client.send = send;
    client.startTrace = startTrace;
    client.stopTrace = stopTrace;
    client.subscribe = subscribe;
    client.unsubscribe = unsubscribe;

    return client;

    // onConnectionLost callback

    function _call(cb, args) {
        if (client._client) {
            cb.apply(this, args);
        } else {
            console.log('Angular-Paho: Client must be initialized first.  Call init() function.');
        }
    }

    function onConnectionLost(resp) {
        console.log("Angular-Paho: Connection lost on ", client._id, ", error code: ", resp);
        client._isConnected = false;
    }

    // connects to the MQTT Server
    function connect(options) {
        _call(_connect, [options]);
    }

    function _connect(options) {
        client._client.connect(options);
        client._isConnected = client._client.isConnected();
    }

    function disconnect() {
        _call(_disconnect);
    }

    function _disconnect() {
        client._client.disconnect();
        client._isConnected = false;
    }

    function init(location, port, id) {
        // initialize attributes
        client._location = location;
        client._port = port;
        client._id = id;

        // create the client and callbacks
        client._client = new Paho.MQTT.Client(client._location, Number(client._port), client._id);
        client._client.onConnectionLost = onConnectionLost;
        client._client.onMessageArrived = onMessageArrived;
    }

    function onMessageArrived(message) {

        //console.log('Subscribed successfully..');

        var beaconID        =      message.payloadString.split(',')[1];
        var beaconName = '';

       // beaconName = $rootScope.beacons[beaconID];

     //console.log('id : '+beaconID+ 'name' + beaconName + 'gateway' + message.payloadString.split(',')[2]);

        //if(beaconID=='D42202001387' || beaconID=='D42202001385') {

        if(message.payloadString.split(',')[3].substring(1)<60) {

        if(beaconID.startsWith('D422020013')) {

            var gateWayID       =     message.payloadString.split(',')[2];
            var Proximity       =     message.payloadString.split(',')[3].substring(1);

            var ProxColorCode   =  getColorCodeByProximity(Proximity);

            var gatewayName='';

            if(gateWayID=='CF8A249B1770' || gateWayID=='D706EFC57465') {

                //console.log(appSettings.gateways[gateWayID]);
                gatewayName = appSettings.gateways[gateWayID];
            }


            var resultMessage   = '{'+

                '"Beacon_ID"'+ ":" +'"'+ beaconID + '"'+ ","+
                '"Gateway_ID"'+":" +'"'+ gateWayID + '"'+ ","+
                '"Proximity"'+" :" + Proximity + "," +
                '"color"'+ ":" + '"'+ProxColorCode+'"'+ ","+
                '"Beacon_Name"'+ ":" +'"'+ beaconName + '"'+  ","+
                    '"Gateway_Name"'+ ":" +'"'+ gatewayName + '"'+
                '}';

            MessageService.update(JSON.parse(resultMessage));
         // console.log(resultMessage);
        }
        }
    }

    function getColorCodeByProximity(Proximity) {

        if(Proximity > 90) {
            return "red";
        } else if(Proximity > 50) {
            return "orange";
        } else {
            return "green";
        }
    }

    function send(message) {
        _call(_send, [message]);
    }

    function _send(message) {
        client._client.send(message);
    }

    function startTrace() {
        _call(_startTrace);
    }

    function _startTrace() {
        client._client.startTrace();
    }

    function stopTrace() {
        _call(_stopTrace);
    }

    function _stopTrace() {
        client._client.stopTrace();
    }

    function subscribe(filter, options) {
        _call(_subscribe, [filter, options]);
    }

    function _subscribe(filter, options) {
        client._client.subscribe(filter, options);
    }

    function unsubscribe(filter, options) {
        _call(_unsubscribe, [filter, options]);
    }

    function _unsubscribe(filter, options) {
        client._client.unsubscribe(filter, options);
    }


});