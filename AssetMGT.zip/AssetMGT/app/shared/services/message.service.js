
angular
    .module('myApp').service('MessageService', function ($rootScope, $timeout) {

    var messages = {};

    messages.beaconStatus = '';

    messages.update = function(message){

       /* Start - set the data for displaying data per beacon */
       
        for(i = 0 ; i < $rootScope.beacons.length; i ++) {

            if($rootScope.beacons[i].id===message.Beacon_ID) {

                $rootScope.beacons[i].Proximity=message.Proximity;
                $rootScope.beacons[i].color=message.color;
                $rootScope.beacons[i].Gateway_ID=message.Gateway_ID;
                $rootScope.beacons[i].status='A';
            }

        }
        $timeout(function(){
            $rootScope.$broadcast('messages:updated',$rootScope.beacons);
        });

        /* End - set the data for displaying data per beacon */
        
        /* Start - set data for displaying data per room,if beacon moves in to the room data but be added and if moves out it must be removed */
        
        //check if it beacon is in any of the listed rooms/gateways

       /* for(i = 0 ; i < $rootScope.rooms.length; i ++) { */
            
            /*if($rootScope.rooms.message.Gateway_ID.beaconsActive.indexOf(message.Beacon_ID) !=-1) {


            }*/

                //console.log('gateway id : ' +message.Gateway_ID);

                //Add the beacon if its entering the room/gateway first time remove it from the preivous room/gateway
               /* if($rootScope.rooms[i].beaconsActive.length > 0) {

                    if($rootScope.rooms[i].beaconsActive.indexOf(message.Beacon_ID) !=-1 ) {

                        //update the proximity since the beacon is already in the room
                        for(j = 0; j < $rootScope.rooms[i].beaconsActive.length ; j++) {

                            if($rootScope.rooms[i].beaconsActive[j]===message.Beacon_ID) {
                                $rootScope.rooms[i].beaconsActive[j].Proximity=message.Proximity;
                            }
                        }

                    } else {
                        //add the beacon message and remove it from the previous room/gateway

                        var bName = getNameForBeaconID(message.Beacon_ID);
                        $rootScope.rooms[i].beaconsActive.push({"Beacon_Name": bName, "Proximity" : message.Proximity ,"beaconID" : message.Beacon_ID});

                        removeBeaconFromRoom(message.Gateway_ID, message.Beacon_ID);

                    }
                } else {*/
                    //add the beacon message directly

                    /*var bName = getNameForBeaconID(message.Beacon_ID);
                    $rootScope.rooms[i].beaconsActive.push({"Beacon_Name": bName, "Proximity" : message.Proximity ,"beaconID" : message.Beacon_ID});

               // }

                
            }
        }


        $timeout(function(){
            $rootScope.$broadcast('room messages:updated',$rootScope.rooms);
        });*/
        
        //update the beacon proximity if its already in that room/gateway
        
        
        
        /* End - set data for displaying data per room,if beacon moves in to the room data but be added and if moves out it must be removed */
    };
    messages.get = function () {

        return $rootScope.beacons;
    }

    function removeBeaconFromRoom(gatewayID, beaconID) {

        for(i = 0 ; i < $rootScope.rooms.length; i ++) {

            if($rootScope.rooms[i].id===message.Gateway_ID) {

                for(j = 0; j < $rootScope.rooms[i].beaconsActive.length ; j++) {

                    if($rootScope.rooms[i].beaconsActive[j].beaconID==beaconID) {

                        $rootScope.rooms[i].beaconsActive.splice(j , 1);
                    }

                }



            }
        }

    }

    function getNameForBeaconID(beaconID) {

        for(i = 0; i < $rootScope.beacons.length ; i++) {

            if($rootScope.beacons[i].id==beaconID) {

                return $rootScope.beacons[i].Beacon_Name;

            } else {
                console.log('beacon name not found for ID : ' +beaconID);
            }

        }
    }




    return messages;
});