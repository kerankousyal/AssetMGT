(function () {

    angular.module('myApp').
    run(['$rootScope','$location', '$http', function( $rootScope, $location, $http) {

        $http.get('assets/data/beacons.json').success( function (data) {

            $rootScope.beacons = data;
        });

        $http.get('assets/data/rooms.json').success( function (data) {

            $rootScope.rooms = data;
        });
    }]);

})();



