(function(){
    'use strict';

    angular.module('myApp').

    directive('preventClick', function () {

        return {

            restrict : 'E',
            link: function(scope, element, attr) {

                console.log('link...');
                $(element).click(function(event) {
                    event.preventDefault();
                });
            }
        };
    });

})();